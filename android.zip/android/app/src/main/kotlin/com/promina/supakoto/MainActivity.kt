package com.promina.supakoto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
