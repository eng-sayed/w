// import 'package:hive/hive.dart';
// import 'package:hive_flutter/hive_flutter.dart';

// class HiveLocal {
//   static Box? localCart;
//   static Box? localWishList;

//   static init() async {
//     await Hive.initFlutter();
//     localCart = await Hive.openBox('services');
//     // localWishList = await Hive.openBox('localWishList');
//   }
// }
